# Proof360 Operational Field — Logo Assets

14 brand SVGs for the OperationalField component.

## Real brand SVGs (drop-in ready)

Sourced from gilbarbara/logos (official-style multi-colour brand marks):
- aws.svg
- microsoft.svg
- openai.svg
- cloudflare.svg
- nvidia.svg
- anthropic.svg
- perplexity.svg
- gemini.svg

Sourced from Simple Icons, brand colour injected:
- cisco.svg (#1BA0D7)
- palo-alto.svg (#FA582D)

## Placeholder wordmarks

Clean text wordmarks in approximate brand colours. Replace with official SVGs from each vendor's press page when convenient:
- vanta.svg — replace from vanta.com brand resources
- ingram.svg — replace from corporate.ingrammicro.com
- apollo-secure.svg — replace from apollosecure.com
- austbrokers-cyberpro.svg — replace from austbrokers.com.au

The placeholders work fine at the low opacities in the spec. The page won't look broken with them. They just won't be the official marks.

## Usage

Drop the entire folder into `src/components/OperationalField/logos/`.

The spec references each by filename — the names already match.
